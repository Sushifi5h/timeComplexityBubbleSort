g++ -Wall -g -std=c++0x pa1.cpp pa1.h -o pa1 
#./pa1 10
#./pa1 50
#./pa1 100
#./pa1 500
#./pa1 1000
#./pa1 5000
#./pa1 10000
#./pa1 50000
#./pa1 100000